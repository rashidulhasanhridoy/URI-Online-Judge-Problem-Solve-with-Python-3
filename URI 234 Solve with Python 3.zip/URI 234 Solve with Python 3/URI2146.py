try:
    while True:
        X = int(input(''))
        Y = X - 1
        print(Y)
except EOFError: exit()
