#include <stdio.h>
#include <math.h>
int prime(int n)
{
    int i, count = 0, r = 0;
    if (n == 0 || n == 1){
        return 1;
    }
    else{
        count = 0;
        r = sqrt(n);
        for(i = 2; i < r; i++){
            if(n % i == 0){
                return 1;
                break;
            }
        }
    }
}
int main()
{
    int n, x, i, j;
    scanf("%d", &n);
    for(i = 0; i <n; i++){
        scanf("%d", &x);
        j = prime(x);
        if(j == 1){
            printf("Not Prime\n");
        }
        else{
            printf("Prime\n");
        }
    }
    return 0;
}
