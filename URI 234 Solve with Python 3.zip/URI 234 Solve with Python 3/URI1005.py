A = float(input(''))
B = float(input(''))
MEDIA = ((A * 3.5) + (B * 7.5)) / (3.5 + 7.5)
print('MEDIA = %0.5f' %MEDIA)