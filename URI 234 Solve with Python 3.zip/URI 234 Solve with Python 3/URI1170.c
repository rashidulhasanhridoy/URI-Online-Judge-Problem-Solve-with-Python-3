#include <stdio.h>
int main()
{
    int n, i, count = 0;
    double X;
    scanf("%d", &n);
    for(i = 0; i < n; i++)
    {
        scanf("%lf", &X);
        while(X > 1)
        {
            X /= 2;
            count ++;
        }

        printf("%d dias\n", count);
        count = 0;
    }

    return 0;
}
