N = str(input(''))
length = len(N)
if length <= 80:
    print('YES')
else:
    print('NO')