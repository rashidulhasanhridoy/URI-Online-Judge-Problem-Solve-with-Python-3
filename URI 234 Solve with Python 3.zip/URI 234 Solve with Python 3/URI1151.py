count = 0
N = int(input(''))
a, b = 0, 1
while True:
    if count == N - 1:
        print(a)
        break
    else:
        print(a, end = ' ')
        count += 1
        a, b = b, a + b