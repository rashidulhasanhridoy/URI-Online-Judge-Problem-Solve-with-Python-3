N = int(input(''))
for i in range(N):
    X = int(input(''))
    if X == 1:
        print('Not Prime')
    else:
        for i in range(2, X):
            if X % i == 0:
                print('Not Prime')
                break
        else:
            print('Prime')