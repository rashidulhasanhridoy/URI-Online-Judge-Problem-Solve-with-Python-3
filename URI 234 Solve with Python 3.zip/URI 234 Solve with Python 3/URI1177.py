N = int(input(''))
j = 0
for i in range(1000):
    print('N[%d] =' %i, j)
    j = j + 1
    if j == N:
        j = 0