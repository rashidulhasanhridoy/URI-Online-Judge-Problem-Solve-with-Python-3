N = int(input(''))
for i in range(N):
    X = str(input(''))
    if X[-1] == 'n':
        print('Case %d:' %(i + 1))
        Y = int(X[:-4], 2)
        print(Y, 'dec')
        Z = hex(Y)
        print(Z[2:], 'hex')
        print(sep = '', end = '\n')
    elif X[-1] == 'c':
        print('Case %d:' % (i + 1))
        Y = hex(int(X[:-4]))
        print(Y[2:], 'hex')
        Z = bin(int(X[:-4]))
        print(Z[2:], 'bin')
        print(sep='', end='\n')
    elif X[-1] == 'x':
        print('Case %d:' % (i + 1))
        Y = int(X[:-4], 16)
        print(Y, 'dec')
        Z = bin(Y)
        print(Z[2:], 'bin')
        print(sep='', end='\n')