N = int(input(''))
for i in range(N):
    K = int(input(''))
    for i in range(K):
        X = int(input(''))
        if X == 1:
            print('Rolien')
        elif X == 2:
            print('Naej')
        elif X == 3:
            print('Elehcim')
        elif X == 4:
            print('Odranoel')