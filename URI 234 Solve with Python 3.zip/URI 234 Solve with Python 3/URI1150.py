count = 0
sum = 0
X = int(input(''))
while True:
    N = int(input(''))
    if N > X:
        break
for i in range(X, N+1):
    count += 1
    sum = sum + i
    if sum > N:
        break
print(count)
