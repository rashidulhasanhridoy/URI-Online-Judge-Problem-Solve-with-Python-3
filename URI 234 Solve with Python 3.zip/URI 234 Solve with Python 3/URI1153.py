N = int(input(''))
sum = 1
for i in range(1, N):
    sum = sum * (N - i)
print(N *sum)