N = int(input(''))
if N == 0:
    print('E')
elif N >= 1 and N <= 35:
    print('D')
elif N >= 36 and N <= 60:
    print('C')
elif N >= 61 and N <= 85:
    print('B')
elif N >= 86 and N <= 100:
    print('A')