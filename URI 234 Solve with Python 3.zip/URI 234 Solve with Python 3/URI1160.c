#include <stdio.h>
int main()
{
    int N, i, j;
    long PA, PB;
    double G1, G2;
    scanf("%d", &N);
    for(i = 0; i < N; i++)
    {
        scanf("%ld %ld", &PA, &PB);
        scanf("%lf %lf", &G1, &G2);
        for(j = 1; j <= 100; j++)
        {
            PA += (long)(PA * G1 / 100);
            PB += (long)(PB * G2 / 100);
            if(PA > PB)
                break;
        }
        if(j > 100)
            printf("Mais de 1 seculo.\n");
        else
            printf("%d anos.\n", j);
    }
    return 0;
}
