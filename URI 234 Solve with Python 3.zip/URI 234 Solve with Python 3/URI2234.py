M, P = map(int, input().split())
rational = M / P
print('%0.2f' %rational)