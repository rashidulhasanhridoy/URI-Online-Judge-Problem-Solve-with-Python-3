N = int(input(''))
for i in range(1, 10000 + 1):
    if i % N == 2:
        print(i, sep = '\n')