import java.io.IOException;
 
public class Main {
	public static void main(String[] args) {
		System.out.printf("---------------------------------------\n");
		System.out.printf("|        Roberto                      |\n");
		System.out.printf("|                                     |\n");
		System.out.printf("|        5786                         |\n");
		System.out.printf("|                                     |\n");
		System.out.printf("|        UNIFEI                       |\n");
		System.out.printf("---------------------------------------\n");
	}
}
