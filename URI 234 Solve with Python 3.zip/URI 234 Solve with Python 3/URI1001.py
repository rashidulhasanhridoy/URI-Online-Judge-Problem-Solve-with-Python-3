A = int(input(''))
B = int(input(''))
X = A + B
print('X =', X)