A = int(input(''))
B = int(input(''))
print('SOMA =', A + B)