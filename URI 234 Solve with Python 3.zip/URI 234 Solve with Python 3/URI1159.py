sum = 0
while True:
    X = int(input(''))
    if X == 0:
        break
    else:
        for i in range(X, X + 10):
            if i % 2 == 0:
                sum += i
        print(sum)
        sum = 0
