O = str(input(''))
sum = 0
for i in range(12):
    for j in range(12):
        X = float(input(''))
        if i < j and j > 11 - i:
            sum += X
if O == 'S':
    print('%0.1f' %sum)
elif O == 'M':
    avaerage = sum / 30.0
    print('%0.1f' %avaerage)