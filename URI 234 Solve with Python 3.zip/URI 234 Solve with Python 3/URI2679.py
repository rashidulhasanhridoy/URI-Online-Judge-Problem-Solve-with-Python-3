X = int(input(''))
for i in range(X+1, X+3):
    if i % 2 == 0:
        print(i)
        break