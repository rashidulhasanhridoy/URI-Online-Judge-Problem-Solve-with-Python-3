D, M, Y = map(str, input().split('/'))
print(M, '/', D, '/', Y, sep = '')
print(Y, '/', M, '/', D, sep = '')
print(D, '-', M, '-', Y, sep = '')