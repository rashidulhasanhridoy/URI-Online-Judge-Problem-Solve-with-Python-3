N = int(input(''))
for i in range(N):
    P = int(input(''))
    if P % 2 == 0:
        print('1')
    if P % 2 == 1:
        print('9')