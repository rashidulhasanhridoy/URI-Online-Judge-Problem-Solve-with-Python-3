for i in range(10):
    X = int(input(''))
    if X == 0 or X < 0:
        X = 1
        print('X[%d] =' %i, X)
    else:
        print('X[%d] =' %i, X)