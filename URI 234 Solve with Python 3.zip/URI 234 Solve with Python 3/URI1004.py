A = int(input(''))
B = int(input(''))
print('PROD =', A * B)