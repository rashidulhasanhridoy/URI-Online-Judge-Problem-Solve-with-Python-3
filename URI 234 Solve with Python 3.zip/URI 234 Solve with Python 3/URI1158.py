N = int(input(''))
sum = 0
for i in range(N):
    X, Y = map(int , input().split())
    for i in range(X, X + ( Y * 2)):
        if i % 2 != 0:
            sum += i
    print(sum)
    sum = 0
