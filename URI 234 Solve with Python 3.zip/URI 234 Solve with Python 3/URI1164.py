N = int(input(''))
for i in range(N):
    sum = 0
    X = int(input(''))
    for i in range(1, X):
       if X % i == 0:
        sum += i
    if sum == X:
        print(X, 'eh perfeito')
        sum = 0
    else:
        print(X, 'nao eh perfeito')
        sum = 0