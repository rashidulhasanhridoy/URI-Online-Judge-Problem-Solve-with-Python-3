N = int(input(''))
M = (N * (N - 3)) // 2
print(M)