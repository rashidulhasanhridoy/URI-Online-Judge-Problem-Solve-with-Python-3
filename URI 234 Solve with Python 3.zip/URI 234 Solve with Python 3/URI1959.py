N, L = map(int, input().split())
P = N * L
print(P)