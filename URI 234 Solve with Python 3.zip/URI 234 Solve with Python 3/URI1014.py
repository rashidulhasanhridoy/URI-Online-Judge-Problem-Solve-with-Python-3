X = int(input(''))
Y = float(input(''))
speed = X / Y
print('%0.3f km/l' %speed)