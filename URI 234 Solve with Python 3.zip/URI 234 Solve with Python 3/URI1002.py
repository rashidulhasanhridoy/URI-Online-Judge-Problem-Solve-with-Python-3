R = float(input(''))
A = 3.14159 * (R ** 2)
print('A=%0.4f' %A)