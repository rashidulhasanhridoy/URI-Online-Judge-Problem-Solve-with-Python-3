X = list(map(int, input('').split()))
for i in X:
    if i == 1:
        print(X.index(i) + 1)
