X, Y = map(float, input().split())
M = ((Y - X) / X) * 100
print('%0.2f' %M, '%', sep = '')