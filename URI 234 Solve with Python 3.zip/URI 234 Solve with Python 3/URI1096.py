I = -1
for i in range(1, 6):
    i = I + 2
    print('I=%d J=%d' % (i, 7))
    print('I=%d J=%d' % (i, 6))
    print('I=%d J=%d' % (i, 5))
    I = i