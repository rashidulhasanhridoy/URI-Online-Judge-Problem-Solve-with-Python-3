S = 0
j = 1
for i in range(1, 39):
    if i % 2 != 0:
        S = S + i / j
        j = j * 2
print('%0.2f' %S)