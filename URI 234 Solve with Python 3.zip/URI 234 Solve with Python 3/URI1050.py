number = int(input(''))
if number == 61:
    print('Brasilia')
elif number == 71:
    print('Salvador')
elif number == 11:
    print('Sao Paulo')
elif number == 21:
    print('Rio de Janeiro')
elif number == 32:
    print('Juiz de Fora')
elif number == 19:
    print('Campinas')
elif number == 27:
    print('Vitoria')
elif number == 31:
    print('Belo Horizonte')
else:
    print('DDD nao cadastrado')