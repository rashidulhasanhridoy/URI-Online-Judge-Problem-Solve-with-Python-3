C =int(input(''))
for i in range(C):
    X = str(input(''))
    length = len(X)
    T = length / 100
    print('%0.2f' %T)