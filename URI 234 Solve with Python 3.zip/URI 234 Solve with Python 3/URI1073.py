N = int(input(''))
for i in range(1, N + 1):
    if i % 2 == 0:
        print('%d^2' %i, '=', i **2)