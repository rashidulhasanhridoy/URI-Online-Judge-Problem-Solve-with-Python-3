N = int(input(''))
for i in range(N):
    S = input()
    N1 = int(S[0])
    C = S[1]
    N2 = int(S[2])
    if N1 == N2:
        print('%d' %(N1 * N2))
    elif ord(C) >= 65 and ord(C) <= 90:
        print('%d' %(N2 - N1))
    elif ord(C) >= 97 and ord(C) <= 122:
        print('%d' %(N2 + N1))