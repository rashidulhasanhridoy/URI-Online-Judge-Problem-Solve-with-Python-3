C = int(input(''))
sum = 0
average = 0
count = 0
for i in range(C):
    X = list(map(int, input().split()))
    for i in range(1, len(X)):
        sum = sum + X[i]
    average = sum / X[0]
    for i in range(1, len(X)):
        if X[i] > average:
            count += 1
    print('%0.3f' %((count / X[0]) * 100.00), '%', sep = '')
    sum = 0
    count = 0
    average = 0