N = int(input(''))
if N == 1:
    print('Ho!')
else:
    for i in range(1, N):
        print('Ho ', end = '')
    if N != 0:
        print('Ho!')