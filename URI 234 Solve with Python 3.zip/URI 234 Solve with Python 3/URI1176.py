numners = [0,1]
a = 0
b = 1
for i in range(60):
    c = b + a
    numners.append(c)
    a = b
    b = c
N = int(input())
for i in range(N):
    X = int(input(''))
    print('Fib(%d) = %d' %(X, numners[X]))