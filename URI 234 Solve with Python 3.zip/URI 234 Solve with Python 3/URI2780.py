D = int(input(''))
if D <= 800:
    print('1')
elif D > 800 and D <= 1400:
    print('2')
elif D > 1400 and D <= 2000:
    print('3')