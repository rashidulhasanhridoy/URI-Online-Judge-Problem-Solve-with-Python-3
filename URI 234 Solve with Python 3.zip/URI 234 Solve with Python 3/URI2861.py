C = int(input(''))
for i in range(C):
    X = str(input(''))
    print('gzuz')