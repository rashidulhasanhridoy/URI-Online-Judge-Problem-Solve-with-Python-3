Y = str(input(''))
X = Y.lower()
Z = 'zelda'
if Z in X:
    print('Link Bolado')
else:
    print('Link Tranquilo')