Am = 0
Bm = []
N = int(input(''))
for i in range(N):
    A = float(input(''))
    Am += A
    B = input('').split(' ')
    Bm.append(len(B))
for i in range(len(Bm)):
    Bm[i] = int(Bm[i])
for i in range(len(Bm)):
    print('day %d: %d kg' %(i + 1, Bm[i]))
C = 0
for i in Bm:
    C += i
print('%0.2f kg by day' %(C / len(Bm)))
print('R$ %0.2f by day' %(Am / len(Bm)))