N = float(input(''))
for i in range(100):
    print('N[%d] =' %i, '%0.4f' %N)
    N = N / 2