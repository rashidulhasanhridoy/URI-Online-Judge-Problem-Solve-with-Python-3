#include <stdio.h>
int main()
{
    long int n;
    scanf("%ld", &n);
    printf("%X\n", n);
    return 0;
}
