for i in range(100):
    X = float(input(''))
    if X < 10 or X == 10:
        print('A[%d] =' %i, '%0.1f' %X)