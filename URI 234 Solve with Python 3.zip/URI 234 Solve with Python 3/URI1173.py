N = int(input(''))
for i in range(10):
    print('N[%d] =' %i, N )
    N = N * 2