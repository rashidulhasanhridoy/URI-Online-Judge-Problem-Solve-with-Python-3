X = input('')
Z = input('')
if X < Z:
    print(X, Z, sep = '\n')
else:
    print(Z, X, sep = '\n')