A, B = map(int, input().split())
if A > B:
    C = A
elif A < B:
    C = B
else:
    C = A
print(C)