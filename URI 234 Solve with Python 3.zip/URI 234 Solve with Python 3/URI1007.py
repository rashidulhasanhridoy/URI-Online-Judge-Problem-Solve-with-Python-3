A = int(input(''))
B = int(input(''))
C = int(input(''))
D = int(input(''))
DIFERENCA = A * B - C * D
print('DIFERENCA =', DIFERENCA)
