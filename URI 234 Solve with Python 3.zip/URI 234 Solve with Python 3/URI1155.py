S = 0
for i in range(1, 101):
    S = S + 1.0 / i
print('%0.2f' %S)