X = str(input(''))
if X == 'roraima':
    print('Regiao Norte')
elif X == 'acre':
    print('Regiao Norte')
elif X == 'amapa':
    print('Regiao Norte')
elif X == 'amazonas':
    print('Regiao Norte')
elif X == 'para':
    print('Regiao Norte')
elif X == 'rondonia':
    print('Regiao Norte')
elif X == 'tocantins':
    print('Regiao Norte')
else:
    print('Outra regiao')