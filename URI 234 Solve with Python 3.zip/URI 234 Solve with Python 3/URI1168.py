sum = 0
N = int(input(''))
for i in range(N):
    X = str(input(''))
    for i in range(len(X)):
        if X[i] == '1':
            sum += 2
        elif X[i] == '2':
            sum += 5
        elif X[i] == '3':
            sum += 5
        elif X[i] == '4':
            sum += 4
        elif X[i] == '5':
            sum += 5
        elif X[i] == '6':
            sum += 6
        elif X[i] == '7':
            sum += 3
        elif X[i] == '8':
            sum += 7
        elif X[i] == '9':
            sum += 6
        elif X[i] == '0':
            sum += 6
    print(sum, 'leds')
    sum = 0