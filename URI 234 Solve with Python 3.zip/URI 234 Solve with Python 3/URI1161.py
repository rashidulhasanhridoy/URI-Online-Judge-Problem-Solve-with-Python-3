def fectorial(n):
    x = 1
    if n == 0 or n == 1:
        return 1
    else:
        for i in range(1, n):
            x = x * (n - i)
        return x * n
while True:
  try:
    M, N = map(int, input().split())
    sum = fectorial(M) + fectorial(N)
    print(sum)
  except EOFError:
    break
