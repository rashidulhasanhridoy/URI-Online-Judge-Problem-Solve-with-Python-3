N = int(input(''))
M = int(input(''))
O = N - M
print(O)