N = int(input(''))
str = 'LIFE IS NOT A PROBLEM TO BE SOLVED'
print(str[:N])