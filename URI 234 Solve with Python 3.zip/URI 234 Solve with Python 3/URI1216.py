sum = 0
count = 0
while True:
  try:
      S = str(input(''))
      D = int(input(''))
      sum = sum + D
      count = count + 1
  except EOFError:
      average = sum / count
      print('%0.1f' % average)
      break