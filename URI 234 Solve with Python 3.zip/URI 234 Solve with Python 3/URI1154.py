sum = 0
count = 0
while True:
    X = int(input(''))
    if X < 0:
        break
    else:
        count += 1
        sum += X
average = sum / count
print('%0.2f' %average)