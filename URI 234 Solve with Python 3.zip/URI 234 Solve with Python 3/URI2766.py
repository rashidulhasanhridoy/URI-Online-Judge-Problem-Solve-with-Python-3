names = []
for i in range(10):
    X =str(input(''))
    names.append(X)
print(names[2])
print(names[6])
print(names[8])