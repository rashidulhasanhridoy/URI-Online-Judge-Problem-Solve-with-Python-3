Numbers = []
for i in range(20):
    X = int(input(''))
    Numbers.insert(i, X)
Numbers.reverse()
j = 0
for i in Numbers:
    print('N[%d] =' %j, i)
    j = j + 1