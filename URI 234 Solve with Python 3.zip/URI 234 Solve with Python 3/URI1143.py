N = int(input(''))
for i in range(1, N + 1):
    print(i, i ** 2, i ** 3)