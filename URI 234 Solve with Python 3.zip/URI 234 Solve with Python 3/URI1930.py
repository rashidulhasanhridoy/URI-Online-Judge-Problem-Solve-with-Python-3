A, B, C, D = map(int, input().split())
X = A + B + C + D - 3
print(X)