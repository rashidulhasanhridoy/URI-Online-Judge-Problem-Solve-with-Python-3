sum = 0
anumbers = []
numbers = []
X = input()
anumbers = X.split()
for i in range(len(anumbers)):
    anumbers[i] = int(anumbers[i])
j = 1
for i in anumbers:
    if i != 0 and i > 0:
        numbers.insert(j, i)
        j += 1
for i in range(numbers[0], numbers[0] + numbers[1]):
    sum += i
print(sum)
