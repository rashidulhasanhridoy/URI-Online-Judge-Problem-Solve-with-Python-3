Number = int(input(''))
Hour = int(input(''))
Amount = float(input(''))
SALARY = Hour * Amount
print('NUMBER =', Number)
print('SALARY = U$ %0.2f' %SALARY)