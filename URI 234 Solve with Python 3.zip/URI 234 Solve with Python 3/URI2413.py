t = int(input(''))
t = t * 2
t = t * 2
print(t)