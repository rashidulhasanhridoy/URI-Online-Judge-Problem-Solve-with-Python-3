X = str(input(''))
Y = str(input(''))
Z = str(input(''))
if X[0] == 'v':
    if Y[0] == 'a':
        if Z[0] == 'c':
            print('aguia')
        if Z[0] == 'o':
            print('pomba')
    elif Y[0] == 'm':
        if Z[0] == 'o':
            print('homem')
        if Z[0] == 'h':
            print('vaca')
if X[0] == 'i':
    if Y[0] == 'i':
        if Z[2] == 'm':
            print('pulga')
        if Z[2] == 'r':
            print('lagarta')
    elif Y[0] == 'a':
        if Z[0] == 'h':
            print('sanguessuga')
        if Z[0] == 'o':
            print('minhoca')