Xm, Ym, Xr, Yr = map(int, input('').split())
A = abs(Xm - Xr) + abs(Ym - Yr)
print(A)