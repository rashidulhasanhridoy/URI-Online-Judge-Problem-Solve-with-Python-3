time = int(input(''))
speed = int(input(''))
liters = (time * speed) / 12
print('%0.3f' %liters)