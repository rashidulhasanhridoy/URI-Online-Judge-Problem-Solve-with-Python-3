Numbers = []
N = int(input(''))
X = input()
Numbers = X.split()
for i in range(len(Numbers)):
    Numbers[i] = int(Numbers[i])
small = min(Numbers)
position = Numbers.index(small)
print('Menor valor:', small)
print('Posicao:', position)