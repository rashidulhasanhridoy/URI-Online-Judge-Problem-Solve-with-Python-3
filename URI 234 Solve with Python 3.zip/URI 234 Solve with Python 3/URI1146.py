while True:
    N = int(input(''))
    if N == 0:
        break
    else:
        for i in range(1, N):
            print(i, end = ' ')
        print(N)