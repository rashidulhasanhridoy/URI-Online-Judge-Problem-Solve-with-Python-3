N = str(input(''))
length = len(N)
if length <= 140:
    print('TWEET')
else:
    print('MUTE')