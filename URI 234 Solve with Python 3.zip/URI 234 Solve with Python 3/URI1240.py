N = int(input(''))
for i in range(N):
    X, Y = map(int, input().split())
    A = str(X)
    B = str(Y)
    Z = len(B)
    if B[:] == A[-Z:]:
        print('encaixa')
    else:
        print('nao encaixa')