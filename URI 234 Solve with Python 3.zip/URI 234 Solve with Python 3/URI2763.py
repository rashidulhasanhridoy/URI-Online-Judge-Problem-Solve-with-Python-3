S = str(input(''))
A = S[:3]
B = S[4 : 7]
C = S[8 : 11]
D = S[12 : 15]
print(A, B, C, D, sep = '\n')