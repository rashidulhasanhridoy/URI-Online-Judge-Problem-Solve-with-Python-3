N = int(input(''))
print('%d' %(N - 2))