while True:
    X = str(input(''))
    if X == '-1':
        break
    else:
        if X[0] == '0':
            Y = int(X[2:], 16)
            print(Y)
        else:
            Y = hex(int(X))
            Z = Y[2:]
            print('0x', Z.upper(), sep = '')