while True:
  try:
    v, t = map(int, input().split())
    if t > v:
        d = t - v
    else:
        d = v - t
    print(d)
  except EOFError:
    break