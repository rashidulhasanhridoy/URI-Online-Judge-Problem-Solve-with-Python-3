speed = int(input(''))
print(speed * 2, 'minutos')