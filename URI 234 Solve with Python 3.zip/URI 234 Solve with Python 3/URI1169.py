N = int(input(''))
for i in range(N):
    X = int(input(''))
    print('%d' %(pow(2, X) // 12000), 'kg')