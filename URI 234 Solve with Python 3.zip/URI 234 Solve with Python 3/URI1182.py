C = int(input(''))
O = str(input(''))
sum = 0
for i in range(144):
    X = float(input(''))
    if i == C:
        sum += X
        C += 12
if O == 'S':
    print('%0.1f' %sum)
elif O == 'M':
    avaerage = sum / 12.0
    print('%0.1f' %avaerage)