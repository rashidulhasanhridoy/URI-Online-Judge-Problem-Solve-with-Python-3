N = int(input(''))
for i in range(N):
    X = str(input(''))
print('Ciencia da Computacao')