C = int(input(''))
for i in range(C):
    X = int(input(''))
    if X > 8000:
        print('Mais de 8000!')
    else:
        print('Inseto!')