R = int(input(''))
VOLUME = (4/3.0) * 3.14159 * (R ** 3)
print('VOLUME = %0.3f' %VOLUME)